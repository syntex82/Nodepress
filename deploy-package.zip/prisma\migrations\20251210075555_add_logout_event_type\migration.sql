-- AlterEnum
ALTER TYPE "SecurityEventType" ADD VALUE 'LOGOUT';
